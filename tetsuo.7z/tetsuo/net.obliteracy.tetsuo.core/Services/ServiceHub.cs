﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using net.obliteracy.tetsuo.core.contracts;
using System.ServiceModel;
using System.Data.SqlClient;
using System.Configuration;
using System.Reflection;
using System.ServiceModel.Description;
using System.ServiceModel.Channels;
using net.obliteracy.tetsuo.entities;

namespace net.obliteracy.tetsuo.core.services
{
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]
    public class ServiceHub : IServiceHub
    {
        System.ServiceModel.Channels.Binding binding;
        BindingElement bElement;
        public ServiceHub()
        {
            Spokes = new List<IServiceSpoke>();
            Hosts = new List<ServiceHost>();

            //bElement = new TcpTransportBindingElement();
            //binding = new CustomBinding(bElement);
            binding = new BasicHttpBinding();

        }
        #region IServiceHub Members

        public string Name
        {
            get;
            set;
        }

        public string OriginAddress
        {
            get;
            set;
        }

        public string DestinationAddress
        {
            get;
            set;
        }

        public List<IServiceSpoke> Spokes
        {
            get;
            set;
        }

        public void InitializeSpokes(Guid HubId, string origin, string destination)
        {
            int i = 0;
            EntityManager em = new EntityManager();
            List<Spoke> spokes = em.GetSpokesByHub(HubId);
            foreach (var spoke in spokes)
            {
                IServiceSpoke currentSpoke = new ServiceSpoke();
                currentSpoke.Name = spoke.SpokeName;
                currentSpoke.EndpointName = spoke.SpokeEndpoint;
                currentSpoke.ContractName = spoke.SpokeContract;
                currentSpoke.IsActive = spoke.Active.Value;
                if (currentSpoke.IsActive)
                {
                    try
                    {
                        Assembly asm = Assembly.LoadFile(spoke.SpokeAssembly);
                        Type spokeType = asm.GetType(spoke.SpokeClientClass);
                        Hosts.Add(new ServiceHost(spokeType, new Uri(
                            string.Format(destination + "/{0}/",
                            currentSpoke.Name))));

                        Hosts[i].AddServiceEndpoint(currentSpoke.ContractName, binding,
                        destination + "/" + currentSpoke.EndpointName);
                        ServiceMetadataBehavior behavior;
                        behavior = Hosts[i].Description.Behaviors.Find<ServiceMetadataBehavior>();
                        if (behavior == null)
                        {
                            behavior = new ServiceMetadataBehavior();
                            Hosts[i].Description.Behaviors.Add(behavior);
                        }
                        behavior.HttpGetEnabled = true;
                        //behavior.HttpGetUrl = new Uri(destination + "/" + currentSpoke.EndpointName);
                        Hosts[i].AddServiceEndpoint(typeof(IMetadataExchange), binding,
                        "MEX");
                        i++;
                        Spokes.Add(currentSpoke);
                        Console.WriteLine("ServiceHub: successfully created spoke at endpoint {0}.",
                           destination + "/" + currentSpoke.EndpointName);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("ServiceHub: error encountered when created spoke at endpoint {0}.\r\n{1}",
                           destination + "/" + currentSpoke.EndpointName, ex.Message);
                    }
                }
            }

        }
        public List<ServiceHost> Hosts { get; set; }

        public IServiceSpoke GetServiceSpoke()
        {
            try
            {

                // TODO: Add logic here to fill in availability
                BaseServiceMessage = "OK.";
                return null;
            }
            catch (Exception ex)
            {
                BaseServiceException = ex;
                BaseServiceMessage = "The operation failed.  Please see the BaseServiceException for further details.";
            }
            return null;
        }

        #endregion

        #region IBaseServiceContract Members

        public string GetCoreObject(params string[] values)
        {
            return string.Empty;
        }

        public Exception BaseServiceException
        {
            get;
            set;
        }

        public string BaseServiceMessage
        {
            get;
            set;
        }

        public string GetServiceMessage()
        {
            return BaseServiceMessage;
        }

        #endregion

        #region IBaseServiceContract Members


        public bool IsActive
        {
            get;
            set;
        }

        #endregion
    }
}
