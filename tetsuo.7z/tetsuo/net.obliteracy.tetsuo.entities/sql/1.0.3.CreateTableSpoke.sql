﻿USE [tetsuo]
GO

/****** Object:  Table [dbo].[Spoke]    Script Date: 02/15/2011 19:12:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Spoke](
	[SpokeId] [uniqueidentifier] NOT NULL,
	[HubId] [uniqueidentifier] NOT NULL,
	[SpokeName] [varchar](50) NULL,
	[SpokeContract] [varchar](50) NULL,
	[SpokeBinding] [varchar](50) NULL,
	[SpokeEndpoint] [varchar](50) NULL,
	[SpokeAssembly] [varchar](255) NULL,
	[SpokeClientClass] [varchar](255) NULL,
	[Active] [bit] NULL,
 CONSTRAINT [PK_Spokes] PRIMARY KEY CLUSTERED 
(
	[SpokeId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Spoke]  WITH CHECK ADD  CONSTRAINT [FK_Spokes_Hubs] FOREIGN KEY([HubId])
REFERENCES [dbo].[Hub] ([HubId])
GO

ALTER TABLE [dbo].[Spoke] CHECK CONSTRAINT [FK_Spokes_Hubs]
GO


