﻿USE [tetsuo]
GO

/****** Object:  Table [dbo].[Hub]    Script Date: 02/15/2011 19:11:54 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Hub](
	[HubId] [uniqueidentifier] NOT NULL,
	[HubName] [varchar](50) NULL,
	[HubEndpoint] [varchar](50) NULL,
	[GatewayId] [uniqueidentifier] NULL,
	[Active] [bit] NULL,
 CONSTRAINT [PK_Hubs] PRIMARY KEY CLUSTERED 
(
	[HubId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Hub]  WITH CHECK ADD  CONSTRAINT [FK_Hubs_Gateways] FOREIGN KEY([GatewayId])
REFERENCES [dbo].[Gateway] ([GatewayId])
GO

ALTER TABLE [dbo].[Hub] CHECK CONSTRAINT [FK_Hubs_Gateways]
GO


