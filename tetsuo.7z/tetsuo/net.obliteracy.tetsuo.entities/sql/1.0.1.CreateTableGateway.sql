﻿USE [tetsuo]
GO

/****** Object:  Table [dbo].[Gateway]    Script Date: 02/15/2011 19:11:23 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Gateway](
	[GatewayId] [uniqueidentifier] NOT NULL,
	[GatewayName] [varchar](50) NULL,
	[GatewayBaseUri] [varchar](200) NULL,
	[GatewayDefaultBinding] [varchar](50) NULL,
	[GatewayIsActive] [bit] NULL,
 CONSTRAINT [PK_Gateways] PRIMARY KEY CLUSTERED 
(
	[GatewayId] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Gateway] ADD  CONSTRAINT [DF_Gateways_GatewayIsActive]  DEFAULT ((0)) FOR [GatewayIsActive]
GO


