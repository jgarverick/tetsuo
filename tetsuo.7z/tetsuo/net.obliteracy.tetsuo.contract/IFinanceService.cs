﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace net.obliteracy.tetsuo.contract
{
    [ServiceContract]
    public interface IFinanceService
    {
    }
}
