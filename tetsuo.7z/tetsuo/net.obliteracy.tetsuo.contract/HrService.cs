﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using net.obliteracy.tetsuo.contract;

namespace net.obliteracy.tetsuo.core
{
    // NOTE: If you change the class name "HrService" here, you must also update the reference to "HrService" in App.config.
    public class HrService : IHrService
    {
        public void DoWork()
        {
        }

        #region IHrService Members

        public void DoSomething(string input)
        {
            throw new NotImplementedException();
        }

        #endregion


    }
}
