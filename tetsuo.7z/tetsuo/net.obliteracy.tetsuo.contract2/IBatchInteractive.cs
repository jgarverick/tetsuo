﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace net.obliteracy.tetsuo.contract2
{
    [ServiceContract]
    public interface IBatchInteractive
    {
        [OperationContract]
        void ProcessBatch(string batchId,string domain, string user,string machineName);
    }
}
