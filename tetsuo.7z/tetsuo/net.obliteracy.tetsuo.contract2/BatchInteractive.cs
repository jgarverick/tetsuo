﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Description;

namespace net.obliteracy.tetsuo.contract2
{
    public class BatchInteractive:IBatchInteractive
    {
        #region IBatchInteractive Members

        public void ProcessBatch(string batchId, string domain, string user,string machineName)
        {
            Console.WriteLine("{2} ({0}\\{1}): A request for batch program " + batchId + 
                " was received.",domain,
                user,machineName);
        }

        #endregion
    }
}
